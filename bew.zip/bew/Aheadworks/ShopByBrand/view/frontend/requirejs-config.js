/**
* Copyright 2018 aheadWorks. All rights reserved. 
*  See LICENSE.txt for license details.
*/

var config = {
    map: {
        '*': {
        	 niksNavigation: 'Niks_LayeredNavigation/js/navigation',
            awSbbProductListLayout:  'Aheadworks_ShopByBrand/js/product-list/layout',
            
        }
    },
    paths: {
        'slick': 'Aheadworks_ShopByBrand/js/slick'
    }
};
