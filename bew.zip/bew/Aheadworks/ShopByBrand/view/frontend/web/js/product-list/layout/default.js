/**
* Copyright 2018 aheadWorks. All rights reserved. 
*  See LICENSE.txt for license details.
*/

define([], function () {
    'use strict';

    return {
        /**
         * Init layout
         */
        initLayout: function () {
        }
    };
});
