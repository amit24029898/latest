require(['jquery'], function($) {

    $jq = jQuery.noConflict();


    jQuery('#layered-filter-block, .pages-items').off('click', 'a').on('click', 'a', function (e) {
             e.preventDefault();
             var url = jQuery(this).attr('href');
             alert(url);
             if (url) {
             (function update() {
                 jQuery('body').loader('show');
                     var self = this;

                 jQuery.ajax({
                         url: url,
                         cache: true,
                         type: 'GET',
                         data: {
                             niksAjax: true
                         },
                         success: function (resp) {
                             console.log(resp);
                             document.write(resp)
                             if (resp instanceof Object) {
                                 console.log(resp);
                                 jQuery('html, body').animate({
                                     scrollTop: $('#maincontent').offset().top
                                 }, 400);
                                 self._create();
                                 jQuery('body').loader('hide');
                             }
                         }
                     }).then(function() {           // on completion, restart
                     setTimeout(update, 30000);  // function refers to itself
                     });
                 })();
                    
             }
           
         });
        });        

  